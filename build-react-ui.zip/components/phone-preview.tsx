"use client"

import type { ReactNode } from "react"

interface PhonePreviewProps {
  children: ReactNode
}

export function PhonePreview({ children }: PhonePreviewProps) {
  return (
    <div className="relative">
      {/* Phone Frame */}
      <div className="relative w-[393px] h-[852px] bg-black rounded-[55px] p-3 shadow-2xl shadow-black/30">
        {/* Inner bezel */}
        <div className="relative w-full h-full bg-black rounded-[45px] overflow-hidden">
          {/* Dynamic Island */}
          <div className="absolute top-3 left-1/2 -translate-x-1/2 z-50">
            <div className="w-[120px] h-[35px] bg-black rounded-full" />
          </div>
          
          {/* Screen Content */}
          <div className="relative w-full h-full bg-white rounded-[42px] overflow-hidden">
            {children}
          </div>
          
          {/* Home Indicator */}
          <div className="absolute bottom-2 left-1/2 -translate-x-1/2 w-32 h-1 bg-black rounded-full z-50" />
        </div>
      </div>
      
      {/* Side buttons */}
      {/* Power button */}
      <div className="absolute right-[-2px] top-32 w-[3px] h-20 bg-gray-800 rounded-l-sm" />
      {/* Volume up */}
      <div className="absolute left-[-2px] top-28 w-[3px] h-12 bg-gray-800 rounded-r-sm" />
      {/* Volume down */}
      <div className="absolute left-[-2px] top-44 w-[3px] h-12 bg-gray-800 rounded-r-sm" />
      {/* Mute switch */}
      <div className="absolute left-[-2px] top-20 w-[3px] h-6 bg-gray-800 rounded-r-sm" />
    </div>
  )
}
