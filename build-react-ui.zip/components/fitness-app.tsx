"use client"

import { useState, useEffect } from "react"
import { Bell, Users, RefreshCw, Search, Calendar, Home, Trophy, Gift, User, Plus, Check, X } from "lucide-react"
import { motion, AnimatePresence } from "framer-motion"

// Tap animation component wrapper
const TapButton = ({ children, className, onClick, ...props }: { children: React.ReactNode; className?: string; onClick?: () => void; [key: string]: unknown }) => (
  <motion.button
    className={className}
    onClick={onClick}
    whileTap={{ scale: 0.95 }}
    whileHover={{ scale: 1.02 }}
    transition={{ type: "spring", stiffness: 400, damping: 17 }}
    {...props}
  >
    {children}
  </motion.button>
)

// Confetti particle
const ConfettiParticle = ({ delay, x }: { delay: number; x: number }) => (
  <motion.div
    className="absolute w-2 h-2 rounded-full"
    style={{
      background: ["#eb773c", "#c73f41", "#fbbf24", "#10b981", "#3b82f6"][Math.floor(Math.random() * 5)],
      left: `${x}%`,
    }}
    initial={{ y: 0, opacity: 1, scale: 1 }}
    animate={{
      y: [0, -120, -80],
      x: [0, (Math.random() - 0.5) * 100],
      opacity: [1, 1, 0],
      scale: [1, 1.2, 0.5],
      rotate: [0, 360 * (Math.random() > 0.5 ? 1 : -1)],
    }}
    transition={{
      duration: 1.2,
      delay,
      ease: "easeOut",
    }}
  />
)

export function FitnessApp() {
  const [showSyncPopup, setShowSyncPopup] = useState(false)
  const [showRewardPopup, setShowRewardPopup] = useState(false)
  const [showConfetti, setShowConfetti] = useState(false)
  const [progressWidth, setProgressWidth] = useState(0)
  const [coinPop, setCoinPop] = useState<number | null>(null)

  // Animate progress bar on mount
  useEffect(() => {
    const timer = setTimeout(() => setProgressWidth(66), 500)
    return () => clearTimeout(timer)
  }, [])

  const handleSync = () => {
    setShowSyncPopup(true)
    setTimeout(() => setShowSyncPopup(false), 2000)
  }

  const handleRewardClaim = (day: number) => {
    setCoinPop(day)
    setTimeout(() => setCoinPop(null), 600)
    if (day === 1) {
      setShowRewardPopup(true)
      setShowConfetti(true)
      setTimeout(() => setShowConfetti(false), 1500)
    }
  }

  return (
    <div className="relative flex flex-col h-full bg-gradient-to-b from-[#fefcfa] via-[#fdf8f4] to-[#faf5f0] overflow-hidden">
      {/* Confetti overlay */}
      <AnimatePresence>
        {showConfetti && (
          <div className="absolute inset-0 z-50 pointer-events-none overflow-hidden">
            {Array.from({ length: 30 }).map((_, i) => (
              <ConfettiParticle key={i} delay={i * 0.03} x={10 + Math.random() * 80} />
            ))}
          </div>
        )}
      </AnimatePresence>

      {/* Status Bar */}
      <div className="flex items-center justify-between px-6 py-2 bg-white/80 backdrop-blur-sm">
        <span className="text-sm font-semibold tracking-tight">9:41</span>
        <div className="flex items-center gap-1.5">
          <div className="flex items-end gap-[2px]">
            <div className="w-[3px] h-[4px] bg-black rounded-[1px]" />
            <div className="w-[3px] h-[6px] bg-black rounded-[1px]" />
            <div className="w-[3px] h-[8px] bg-black rounded-[1px]" />
            <div className="w-[3px] h-[10px] bg-black rounded-[1px]" />
          </div>
          <svg className="w-[18px] h-[12px]" viewBox="0 0 18 12" fill="currentColor">
            <path d="M9 0C5.5 0 2.5 1.5 0.5 4L2 5.5C3.5 3 6 1.5 9 1.5s5.5 1.5 7 4L17.5 4C15.5 1.5 12.5 0 9 0zm0 4c-2 0-3.8 1-5 2.5L5.5 8C6.3 6.8 7.5 6 9 6s2.7.8 3.5 2L14 6.5C12.8 5 11 4 9 4zm0 4c-1 0-1.8.5-2.2 1.3L9 11.5l2.2-2.2C10.8 8.5 10 8 9 8z"/>
          </svg>
          <div className="flex items-center">
            <div className="w-[25px] h-[12px] border-[1.5px] border-black rounded-[3px] relative">
              <div className="absolute inset-[2px] right-[3px] bg-black rounded-[1px]" style={{ width: "80%" }} />
            </div>
            <div className="w-[2px] h-[5px] bg-black rounded-r-full ml-[1px]" />
          </div>
        </div>
      </div>

      {/* Header */}
      <div className="flex items-center justify-between px-5 py-3 bg-white/60 backdrop-blur-sm">
        <TapButton className="p-2.5 hover:bg-black/5 rounded-2xl transition-all duration-200">
          <Bell className="w-[22px] h-[22px] text-gray-500" strokeWidth={1.8} />
        </TapButton>
        <TapButton className="flex items-center gap-2 px-4 py-2.5 bg-white rounded-full shadow-[0_2px_12px_rgba(0,0,0,0.06)] border border-gray-100/80 hover:shadow-[0_4px_16px_rgba(0,0,0,0.08)] transition-all duration-200">
          <Users className="w-[18px] h-[18px] text-gray-600" strokeWidth={1.8} />
          <span className="text-sm font-medium text-gray-700">Friends</span>
        </TapButton>
      </div>

      {/* Scrollable Content */}
      <div className="flex-1 overflow-y-auto">
        {/* Hero Card */}
        <div className="px-4 pt-1 pb-5">
          <motion.div 
            className="relative rounded-[28px] p-5 overflow-hidden"
            style={{
              background: "linear-gradient(135deg, #eb773c 0%, #e56a38 25%, #df5d35 50%, #d64a39 75%, #c73f41 100%)",
              boxShadow: "0 12px 40px rgba(199,63,65,0.35), 0 6px 20px rgba(235,119,60,0.25), inset 0 1px 0 rgba(255,255,255,0.15)"
            }}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, ease: "easeOut" }}
          >
            {/* Decorative floating shapes and glows */}
            <div className="absolute top-0 right-0 w-40 h-40 bg-gradient-to-br from-white/20 to-transparent rounded-full blur-3xl" />
            <div className="absolute bottom-0 left-0 w-32 h-32 bg-gradient-to-tr from-[#c73f41]/40 to-transparent rounded-full blur-2xl" />
            <div className="absolute top-1/2 left-1/4 w-20 h-20 bg-white/5 rounded-full blur-xl" />
            
            {/* Floating decorative confetti dots */}
            <motion.div 
              className="absolute top-8 left-12 w-2 h-2 rounded-full bg-white/30"
              animate={{ y: [0, -6, 0], opacity: [0.3, 0.5, 0.3] }}
              transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }}
            />
            <motion.div 
              className="absolute top-16 left-8 w-1.5 h-1.5 rounded-full bg-amber-300/40"
              animate={{ y: [0, -8, 0], opacity: [0.4, 0.6, 0.4] }}
              transition={{ duration: 2.5, repeat: Infinity, ease: "easeInOut", delay: 0.5 }}
            />
            <motion.div 
              className="absolute bottom-20 right-24 w-1.5 h-1.5 rounded-full bg-white/25"
              animate={{ y: [0, -5, 0], opacity: [0.25, 0.4, 0.25] }}
              transition={{ duration: 2.8, repeat: Infinity, ease: "easeInOut", delay: 1 }}
            />
            <motion.div 
              className="absolute top-20 right-32 w-2 h-2 rounded-full bg-yellow-300/30"
              animate={{ y: [0, -7, 0], x: [0, 3, 0] }}
              transition={{ duration: 3.2, repeat: Infinity, ease: "easeInOut", delay: 0.3 }}
            />
            
            {/* Premium Wallet Badge with glow pulse */}
            <motion.div 
              className="absolute -top-2 right-4 z-20"
              initial={{ opacity: 0, scale: 0.8, y: -10 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              transition={{ delay: 0.3, duration: 0.4, type: "spring" }}
            >
              {/* Outer glow pulse */}
              <motion.div 
                className="absolute -inset-2 rounded-2xl"
                style={{ background: "linear-gradient(135deg, rgba(199,63,65,0.4) 0%, rgba(180,50,50,0.3) 100%)" }}
                animate={{ scale: [1, 1.08, 1], opacity: [0.5, 0.7, 0.5] }}
                transition={{ duration: 2.5, repeat: Infinity, ease: "easeInOut" }}
              />
              <div 
                className="relative rounded-2xl px-3.5 py-2.5 border border-white/20"
                style={{
                  background: "linear-gradient(145deg, rgba(199,63,65,0.95) 0%, rgba(180,50,50,0.98) 50%, rgba(160,45,45,1) 100%)",
                  backdropFilter: "blur(8px)",
                  boxShadow: "0 8px 32px rgba(199,63,65,0.5), 0 4px 16px rgba(199,63,65,0.3), inset 0 1px 0 rgba(255,255,255,0.1)"
                }}
              >
                <div className="flex items-center gap-1.5 text-white/80 text-[9px] font-semibold tracking-wider mb-1.5">
                  <svg className="w-3 h-3 opacity-80" viewBox="0 0 24 24" fill="currentColor">
                    <path d="M21 18v1c0 1.1-.9 2-2 2H5c-1.11 0-2-.9-2-2V5c0-1.1.89-2 2-2h14c1.1 0 2 .9 2 2v1h-9c-1.11 0-2 .9-2 2v8c0 1.1.89 2 2 2h9zm-9-2h10V8H12v8zm4-2.5c-.83 0-1.5-.67-1.5-1.5s.67-1.5 1.5-1.5 1.5.67 1.5 1.5-.67 1.5-1.5 1.5z"/>
                  </svg>
                  WALLET
                </div>
                <div className="flex items-center gap-2">
                  {/* Glowing coin icon */}
                  <div className="relative">
                    <motion.div 
                      className="absolute -inset-1 rounded-full bg-amber-400/40"
                      animate={{ scale: [1, 1.3, 1], opacity: [0.4, 0.6, 0.4] }}
                      transition={{ duration: 2, repeat: Infinity }}
                    />
                    <div className="relative w-5 h-5 bg-gradient-to-br from-yellow-300 via-amber-400 to-yellow-500 rounded-full flex items-center justify-center shadow-[0_2px_12px_rgba(251,191,36,0.6)]">
                      <span className="text-[9px]">&#129689;</span>
                    </div>
                  </div>
                  <span className="text-white font-bold text-lg tracking-tight">2,540</span>
                  <motion.div 
                    className="w-4 h-4 bg-gradient-to-br from-yellow-300 via-amber-400 to-amber-500 rounded-full shadow-[0_2px_8px_rgba(251,191,36,0.5)]"
                    animate={{ rotate: [0, 10, -10, 0] }}
                    transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }}
                  />
                </div>
              </div>
            </motion.div>

            {/* Greeting with sparkle */}
            <div className="mb-6 mt-2 relative">
              <motion.div 
                className="absolute -top-1 left-28 text-yellow-300/60 text-sm"
                animate={{ scale: [1, 1.3, 1], opacity: [0.6, 1, 0.6], rotate: [0, 15, 0] }}
                transition={{ duration: 2, repeat: Infinity, delay: 0.5 }}
              >
                &#10022;
              </motion.div>
              <h2 className="text-white text-xl font-bold flex items-center gap-2 tracking-tight">
                Keep going! <span className="text-2xl">&#128293;</span>
                <motion.svg 
                  className="w-4 h-4 text-white/50 ml-1" 
                  viewBox="0 0 24 24" 
                  fill="currentColor"
                  whileHover={{ scale: 1.2, rotate: 15 }}
                  whileTap={{ scale: 0.9 }}
                >
                  <path d="M3 17.25V21h3.75L17.81 9.94l-3.75-3.75L3 17.25zM20.71 7.04c.39-.39.39-1.02 0-1.41l-2.34-2.34c-.39-.39-1.02-.39-1.41 0l-1.83 1.83 3.75 3.75 1.83-1.83z"/>
                </motion.svg>
              </h2>
              <p className="text-white/80 text-[15px] font-light mt-0.5">{"You're doing great today."}</p>
            </div>

            {/* Premium Leaderboard Score Card with trophy */}
            <motion.div 
              className="relative"
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.2, duration: 0.4 }}
            >
              {/* Card shadow layer */}
              <div 
                className="absolute inset-0 rounded-[22px] bg-black/10 blur-xl translate-y-2"
              />
              <div 
                className="relative bg-white rounded-[22px] px-4 py-4 overflow-hidden"
                style={{
                  clipPath: "polygon(0 0, 78% 0, 85% 4%, 92% 12%, 97% 24%, 100% 40%, 100% 100%, 0 100%)",
                  boxShadow: "0 8px 32px rgba(0,0,0,0.08), 0 2px 8px rgba(0,0,0,0.04), inset 0 1px 0 rgba(255,255,255,1)"
                }}
              >
                {/* Inner gradient overlay */}
                <div className="absolute inset-0 bg-gradient-to-br from-white via-white to-gray-50/50 pointer-events-none" />
                
                {/* Trophy illustration positioned at top right */}
                <div className="absolute -top-1 -right-2 w-20 h-20 opacity-90">
                  <svg viewBox="0 0 80 80" className="w-full h-full">
                    <defs>
                      <linearGradient id="trophyGold" x1="0%" y1="0%" x2="100%" y2="100%">
                        <stop offset="0%" stopColor="#fcd34d"/>
                        <stop offset="50%" stopColor="#fbbf24"/>
                        <stop offset="100%" stopColor="#f59e0b"/>
                      </linearGradient>
                      <linearGradient id="trophyShine" x1="0%" y1="0%" x2="100%" y2="0%">
                        <stop offset="0%" stopColor="#fef3c7"/>
                        <stop offset="50%" stopColor="#fde68a"/>
                        <stop offset="100%" stopColor="#fcd34d"/>
                      </linearGradient>
                    </defs>
                    {/* Trophy base */}
                    <rect x="30" y="58" width="20" height="6" rx="2" fill="url(#trophyGold)"/>
                    <rect x="35" y="50" width="10" height="10" rx="1" fill="url(#trophyGold)"/>
                    {/* Trophy cup */}
                    <path d="M25 20 L55 20 L52 42 Q52 50 40 52 Q28 50 28 42 L25 20 Z" fill="url(#trophyGold)" stroke="#f59e0b" strokeWidth="1"/>
                    {/* Trophy handles */}
                    <path d="M25 24 Q15 24 15 34 Q15 42 25 42" fill="none" stroke="url(#trophyGold)" strokeWidth="4" strokeLinecap="round"/>
                    <path d="M55 24 Q65 24 65 34 Q65 42 55 42" fill="none" stroke="url(#trophyGold)" strokeWidth="4" strokeLinecap="round"/>
                    {/* Trophy shine */}
                    <path d="M32 26 L36 26 L34 38 L32 38 Z" fill="url(#trophyShine)" opacity="0.6"/>
                    {/* Star decoration */}
                    <circle cx="40" cy="32" r="6" fill="#fef3c7"/>
                    <text x="40" y="36" textAnchor="middle" fontSize="10" fill="#f59e0b">&#9733;</text>
                  </svg>
                </div>
                
                <div className="relative">
                  <div className="flex items-center gap-1.5 mb-1">
                    <p className="text-gray-400 text-[10px] font-bold tracking-wider">LEADERBOARD SCORE</p>
                    <span className="text-sm">&#128081;</span>
                  </div>
                  <div className="flex items-baseline gap-1.5">
                    <span className="text-[48px] font-extrabold text-gray-800 leading-none tracking-tighter">640</span>
                    <span className="text-xl text-gray-300 font-semibold">pts</span>
                  </div>
                  <p className="text-gray-400 text-[13px] mb-3 font-medium">Spendable: <span className="text-gray-500">540 pts</span></p>
                  
                  <div className="flex items-center gap-3">
                    {/* Streak badge with glow */}
                    <div 
                      className="flex items-center gap-1.5 px-3 py-1.5 rounded-full"
                      style={{
                        background: "linear-gradient(135deg, rgba(235,119,60,0.12) 0%, rgba(199,63,65,0.15) 100%)",
                        border: "1px solid rgba(235,119,60,0.25)",
                        boxShadow: "0 2px 8px rgba(235,119,60,0.1)"
                      }}
                    >
                      <span className="text-sm">&#128293;</span>
                      <span className="text-[#c73f41] font-bold text-xs">2 days</span>
                    </div>
                    {/* Ranked season badge */}
                    <div className="flex items-center gap-1.5 text-gray-500 text-xs">
                      <div className="w-4 h-4 rounded-full bg-gradient-to-br from-[#eb773c]/20 to-[#c73f41]/20 flex items-center justify-center">
                        <svg className="w-2.5 h-2.5 text-[#eb773c]" viewBox="0 0 24 24" fill="currentColor">
                          <path d="M16 6l2.29 2.29-4.88 4.88-4-4L2 16.59 3.41 18l6-6 4 4 6.3-6.29L22 12V6z"/>
                        </svg>
                      </div>
                      <span className="font-semibold">Ranked</span>
                      <span className="text-gray-300">&#183;</span>
                      <span className="font-medium text-gray-400">Season 1</span>
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>

            {/* Premium Animated Progress Bar */}
            <div className="mt-4 relative">
              <div className="h-[6px] bg-white/15 rounded-full overflow-hidden backdrop-blur-sm border border-white/10">
                <motion.div 
                  className="h-full rounded-full relative"
                  style={{ 
                    background: "linear-gradient(90deg, #fcd34d 0%, #fbbf24 40%, #f59e0b 70%, #fcd34d 100%)",
                    backgroundSize: "200% 100%"
                  }}
                  initial={{ width: 0 }}
                  animate={{ 
                    width: `${progressWidth}%`,
                    backgroundPosition: ["0% 0%", "100% 0%"]
                  }}
                  transition={{ 
                    width: { duration: 1, ease: "easeOut", delay: 0.5 },
                    backgroundPosition: { duration: 2, repeat: Infinity, ease: "linear" }
                  }}
                >
                  {/* Glowing edge */}
                  <motion.div 
                    className="absolute right-0 top-1/2 -translate-y-1/2 w-3 h-3 rounded-full bg-amber-300"
                    style={{ boxShadow: "0 0 12px rgba(251,191,36,0.8), 0 0 24px rgba(251,191,36,0.4)" }}
                    animate={{ scale: [1, 1.3, 1], opacity: [0.8, 1, 0.8] }}
                    transition={{ duration: 1.5, repeat: Infinity }}
                  />
                </motion.div>
              </div>
            </div>
          </motion.div>
        </div>

        {/* Daily Progress - Gamified Connected Circles */}
        <motion.div 
          className="px-4 mb-3.5"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3, duration: 0.4 }}
        >
          <div 
            className="relative rounded-[22px] p-4 overflow-hidden"
            style={{
              background: "linear-gradient(135deg, #fffcf9 0%, #fff8f3 50%, #fff5ee 100%)",
              boxShadow: "0 4px 24px rgba(235,119,60,0.08), 0 2px 12px rgba(0,0,0,0.03), inset 0 1px 0 rgba(255,255,255,0.9)",
              border: "1px solid rgba(235,119,60,0.08)"
            }}
          >
            {/* Decorative corner glow */}
            <div className="absolute -top-10 -right-10 w-24 h-24 bg-gradient-to-br from-[#eb773c]/10 to-transparent rounded-full blur-2xl" />
            <div className="absolute -bottom-8 -left-8 w-20 h-20 bg-gradient-to-tr from-[#c73f41]/8 to-transparent rounded-full blur-xl" />
            
            <div className="relative flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <span className="text-gray-800 font-semibold text-[15px]">Daily progress</span>
                {/* Streak badge */}
                <div className="flex items-center gap-1 bg-gradient-to-r from-[#eb773c]/15 to-[#c73f41]/15 px-2 py-0.5 rounded-full border border-[#eb773c]/20">
                  <span className="text-[10px]">&#128293;</span>
                  <span className="text-[#c73f41] font-bold text-[10px]">4 days</span>
                </div>
              </div>
              <div className="flex items-center gap-1.5 bg-white/80 px-2.5 py-1 rounded-full shadow-sm border border-gray-100/80">
                <div className="w-1.5 h-1.5 rounded-full bg-gradient-to-r from-[#eb773c] to-[#c73f41]" />
                <span className="text-gray-600 text-xs font-semibold">3 / 7 km</span>
              </div>
            </div>
            
            {/* Connected progress circles with line */}
            <div className="relative flex items-center justify-between px-1">
              {/* Connecting line background */}
              <div className="absolute top-1/2 left-[18px] right-[18px] h-[3px] -translate-y-1/2 bg-gray-200/60 rounded-full" />
              {/* Animated progress line */}
              <motion.div 
                className="absolute top-1/2 left-[18px] h-[3px] -translate-y-1/2 rounded-full"
                style={{ background: "linear-gradient(90deg, #eb773c 0%, #d65a3e 50%, #c73f41 100%)" }}
                initial={{ width: 0 }}
                animate={{ width: "calc(57% - 18px)" }}
                transition={{ duration: 1.2, ease: "easeOut", delay: 0.6 }}
              />
              
              {[true, true, true, true, false, false, false].map((checked, i) => (
                <motion.div
                  key={i}
                  initial={{ scale: 0, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  transition={{ delay: 0.5 + i * 0.08, type: "spring", stiffness: 300 }}
                  className="relative z-10"
                >
                  {/* Current day glow ring */}
                  {i === 4 && (
                    <motion.div 
                      className="absolute -inset-1.5 rounded-full"
                      style={{ background: "linear-gradient(135deg, rgba(235,119,60,0.3) 0%, rgba(199,63,65,0.2) 100%)" }}
                      animate={{ scale: [1, 1.15, 1], opacity: [0.5, 0.8, 0.5] }}
                      transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
                    />
                  )}
                  <div 
                    className={`relative w-[30px] h-[30px] rounded-full flex items-center justify-center transition-all duration-200 ${
                      checked
                        ? "shadow-[0_3px_12px_rgba(199,63,65,0.4)]"
                        : i === 4
                        ? "shadow-[0_2px_8px_rgba(235,119,60,0.25)]"
                        : ""
                    }`}
                    style={{
                      background: checked 
                        ? "linear-gradient(135deg, #eb773c 0%, #d65a3e 50%, #c73f41 100%)"
                        : i === 4 
                        ? "linear-gradient(135deg, #fff8f3 0%, #fff5ee 100%)"
                        : "linear-gradient(135deg, #fafafa 0%, #f5f5f5 100%)",
                      border: checked ? "2px solid rgba(255,255,255,0.3)" : i === 4 ? "2px solid rgba(235,119,60,0.4)" : "2px solid rgba(0,0,0,0.06)"
                    }}
                  >
                    {checked && <Check className="w-4 h-4 text-white drop-shadow-sm" strokeWidth={2.5} />}
                    {i === 4 && !checked && (
                      <div className="w-2 h-2 rounded-full bg-gradient-to-br from-[#eb773c] to-[#c73f41]" />
                    )}
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </motion.div>

        {/* Daily Mission - Gamified Challenge Card */}
        <motion.div 
          className="px-4 mb-3.5"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4, duration: 0.4 }}
        >
          <div 
            className="relative rounded-[22px] p-4 overflow-hidden"
            style={{
              background: "linear-gradient(145deg, #f0fdf9 0%, #ecfdf5 30%, #f0fdf4 70%, #fefffe 100%)",
              boxShadow: "0 4px 24px rgba(16,185,129,0.1), 0 2px 12px rgba(0,0,0,0.03), inset 0 1px 0 rgba(255,255,255,0.9)",
              border: "1px solid rgba(16,185,129,0.1)"
            }}
          >
            {/* Decorative elements */}
            <div className="absolute -top-8 -right-8 w-28 h-28 bg-gradient-to-br from-emerald-300/20 to-transparent rounded-full blur-2xl" />
            <div className="absolute -bottom-6 -left-6 w-20 h-20 bg-gradient-to-tr from-green-300/15 to-transparent rounded-full blur-xl" />
            {/* Floating dots decoration */}
            <div className="absolute top-6 right-16 w-1.5 h-1.5 rounded-full bg-emerald-300/50" />
            <div className="absolute top-10 right-12 w-1 h-1 rounded-full bg-green-300/40" />
            
            <div className="relative flex items-start justify-between mb-3">
              <div className="flex items-center gap-2.5">
                {/* Mission icon with glow */}
                <div className="relative">
                  <div className="absolute -inset-1 bg-gradient-to-br from-emerald-400/30 to-green-500/20 rounded-2xl blur-sm" />
                  <div className="relative w-11 h-11 bg-gradient-to-br from-emerald-400 via-emerald-500 to-green-600 rounded-2xl flex items-center justify-center shadow-[0_4px_12px_rgba(16,185,129,0.35)]">
                    <svg className="w-5 h-5 text-white" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                      <path d="M13 2L3 14h9l-1 8 10-12h-9l1-8z" strokeLinecap="round" strokeLinejoin="round"/>
                    </svg>
                  </div>
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="font-bold text-gray-800 text-[13px] tracking-tight">DAILY MISSION</h3>
                    {/* Today's goal badge */}
                    <div className="px-2 py-0.5 bg-emerald-500/10 rounded-full border border-emerald-500/20">
                      <span className="text-emerald-600 text-[9px] font-bold tracking-wide">{"TODAY'S GOAL"}</span>
                    </div>
                  </div>
                  <p className="text-gray-600 text-[13px] mt-0.5 font-medium">Walk/Run 7 km today</p>
                </div>
              </div>
              <TapButton 
                className="p-2.5 bg-white/80 hover:bg-white rounded-xl transition-all duration-200 shadow-sm border border-emerald-100/50"
                onClick={handleSync}
              >
                <RefreshCw className="w-[16px] h-[16px] text-emerald-500" strokeWidth={2} />
              </TapButton>
            </div>
            
            {/* Progress section */}
            <div className="relative mt-4 mb-2">
              {/* Progress bar background */}
              <div className="h-[10px] bg-white/80 rounded-full overflow-hidden shadow-inner border border-gray-100/50">
                <motion.div 
                  className="h-full rounded-full relative"
                  style={{ 
                    background: "linear-gradient(90deg, #10b981 0%, #34d399 50%, #6ee7b7 100%)",
                    boxShadow: "0 0 12px rgba(16,185,129,0.4)"
                  }}
                  initial={{ width: 0 }}
                  animate={{ width: "0%" }}
                  transition={{ duration: 1, ease: "easeOut", delay: 0.7 }}
                >
                  {/* Shimmer effect */}
                  <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/30 to-transparent animate-pulse" />
                </motion.div>
              </div>
            </div>
            
            <div className="relative flex items-end justify-between">
              <div className="flex items-center gap-4">
                <div className="flex items-center gap-1.5">
                  <div className="w-5 h-5 rounded-full bg-gradient-to-br from-emerald-100 to-green-100 flex items-center justify-center">
                    <svg className="w-3 h-3 text-emerald-600" viewBox="0 0 24 24" fill="currentColor">
                      <path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5z"/>
                    </svg>
                  </div>
                  <div>
                    <p className="text-gray-700 text-sm font-bold">0.00 <span className="text-gray-400 font-normal">/ 7.00 km</span></p>
                  </div>
                </div>
                <div className="flex items-center gap-1.5">
                  <div className="w-5 h-5 rounded-full bg-gradient-to-br from-emerald-100 to-green-100 flex items-center justify-center">
                    <svg className="w-3 h-3 text-emerald-600" viewBox="0 0 24 24" fill="currentColor">
                      <path d="M13.5 5.5c1.1 0 2-.9 2-2s-.9-2-2-2-2 .9-2 2 .9 2 2 2zM9.8 8.9L7 23h2.1l1.8-8 2.1 2v6h2v-7.5l-2.1-2 .6-3C14.8 12 16.8 13 19 13v-2c-1.9 0-3.5-1-4.3-2.4l-1-1.6c-.4-.6-1-1-1.7-1-.3 0-.5.1-.8.1L6 8.3V13h2V9.6l1.8-.7"/>
                    </svg>
                  </div>
                  <p className="text-gray-500 text-sm">0 steps</p>
                </div>
              </div>
              {/* Shoe illustration */}
              <div className="relative w-16 h-14">
                <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-12 h-2 bg-gradient-to-r from-transparent via-emerald-100/50 to-transparent rounded-full blur-sm" />
                <svg viewBox="0 0 64 48" className="w-full h-full drop-shadow-sm">
                  <defs>
                    <linearGradient id="shoeGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                      <stop offset="0%" stopColor="#5eead4"/>
                      <stop offset="50%" stopColor="#2dd4bf"/>
                      <stop offset="100%" stopColor="#14b8a6"/>
                    </linearGradient>
                  </defs>
                  <ellipse cx="32" cy="44" rx="16" ry="3" fill="#e5e7eb" opacity="0.5"/>
                  <path d="M12 32 L16 14 L28 10 L52 14 L56 28 L52 36 L16 38 Z" fill="white" stroke="#e5e7eb" strokeWidth="1"/>
                  <path d="M18 30 L22 14 L34 12 L50 16 L52 28 L48 34 L20 34 Z" fill="url(#shoeGrad)"/>
                  <path d="M14 35 L18 32 L50 32 L54 35 L52 38 L16 38 Z" fill="#f8fafc" stroke="#e5e7eb" strokeWidth="0.5"/>
                  <circle cx="24" cy="22" r="2" fill="white" opacity="0.4"/>
                  <circle cx="32" cy="20" r="1.5" fill="white" opacity="0.3"/>
                  <path d="M36 16 L48 18" stroke="white" strokeWidth="2" opacity="0.4" strokeLinecap="round"/>
                  <path d="M34 22 L46 24" stroke="white" strokeWidth="1.5" opacity="0.3" strokeLinecap="round"/>
                </svg>
              </div>
            </div>
          </div>
        </motion.div>

        {/* Daily Reward - 7-Day Treasure Tracker */}
        <motion.div 
          className="px-4 mb-3.5"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5, duration: 0.4 }}
        >
          <div 
            className="relative rounded-[22px] p-4 overflow-hidden"
            style={{
              background: "linear-gradient(145deg, #fffbf5 0%, #fff9f0 30%, #fff7eb 70%, #fffcf8 100%)",
              boxShadow: "0 4px 24px rgba(251,191,36,0.12), 0 2px 12px rgba(0,0,0,0.03), inset 0 1px 0 rgba(255,255,255,0.9)",
              border: "1px solid rgba(251,191,36,0.15)"
            }}
          >
            {/* Decorative sparkles and glows */}
            <div className="absolute -top-8 -right-8 w-28 h-28 bg-gradient-to-br from-amber-300/15 to-transparent rounded-full blur-2xl" />
            <div className="absolute -bottom-6 -left-6 w-20 h-20 bg-gradient-to-tr from-yellow-300/10 to-transparent rounded-full blur-xl" />
            {/* Mini stars decoration */}
            <motion.div 
              className="absolute top-5 right-12 text-[8px]"
              animate={{ scale: [1, 1.3, 1], opacity: [0.6, 1, 0.6] }}
              transition={{ duration: 2, repeat: Infinity, delay: 0 }}
            >&#10022;</motion.div>
            <motion.div 
              className="absolute top-8 right-20 text-[6px] text-amber-400"
              animate={{ scale: [1, 1.4, 1], opacity: [0.4, 0.8, 0.4] }}
              transition={{ duration: 2, repeat: Infinity, delay: 0.5 }}
            >&#10022;</motion.div>
            <motion.div 
              className="absolute top-12 right-8 text-[7px] text-yellow-500"
              animate={{ scale: [1, 1.2, 1], opacity: [0.5, 0.9, 0.5] }}
              transition={{ duration: 2, repeat: Infinity, delay: 1 }}
            >&#10022;</motion.div>
            
            <div className="relative flex items-start justify-between mb-4">
              <div className="flex items-center gap-3">
                {/* Treasure chest icon */}
                <div className="relative">
                  <div className="absolute -inset-1 bg-gradient-to-br from-amber-400/25 to-yellow-500/15 rounded-2xl blur-sm" />
                  <div className="relative w-11 h-11 bg-gradient-to-br from-amber-400 via-yellow-500 to-amber-500 rounded-2xl flex items-center justify-center shadow-[0_4px_12px_rgba(251,191,36,0.4)]">
                    <Gift className="w-5 h-5 text-white drop-shadow-sm" strokeWidth={2} />
                  </div>
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="font-bold text-gray-800 text-[13px] tracking-tight">DAILY REWARD</h3>
                    {/* Next reward badge */}
                    <div className="px-2 py-0.5 bg-gradient-to-r from-amber-500/10 to-yellow-500/10 rounded-full border border-amber-400/20">
                      <span className="text-amber-600 text-[9px] font-bold tracking-wide">DAY 2 NEXT</span>
                    </div>
                  </div>
                  <p className="text-gray-500 text-[12px] mt-0.5">Collect coins & points every day!</p>
                </div>
              </div>
            </div>
            
            {/* 7-Day Reward Track */}
            <div className="relative flex items-center justify-between">
              {/* Connecting dotted line */}
              <div className="absolute top-5 left-5 right-5 h-[2px] flex items-center justify-between">
                {[...Array(6)].map((_, i) => (
                  <div key={i} className={`flex-1 h-[2px] mx-0.5 rounded-full ${i < 1 ? "bg-gradient-to-r from-amber-400 to-amber-300" : "bg-amber-200/50"}`} />
                ))}
              </div>
              
              {[
                { day: 1, coins: "10", checked: true, isToday: false },
                { day: 2, coins: "10", checked: false, isToday: true },
                { day: 3, coins: "20", checked: false, isToday: false },
                { day: 4, coins: "30", checked: false, isToday: false },
                { day: 5, coins: "50", checked: false, isToday: false },
                { day: 6, coins: "10", checked: false, isToday: false },
                { day: 7, coins: "100", checked: false, isToday: false, isBig: true },
              ].map((item) => (
                <TapButton 
                  key={item.day} 
                  className="flex flex-col items-center relative z-10"
                  onClick={() => handleRewardClaim(item.day)}
                >
                  {/* Coin pop animation */}
                  <AnimatePresence>
                    {coinPop === item.day && (
                      <motion.div
                        className="absolute -top-6 left-1/2 -translate-x-1/2 flex items-center gap-0.5"
                        initial={{ opacity: 0, y: 0, scale: 0.5 }}
                        animate={{ opacity: 1, y: -16, scale: 1 }}
                        exit={{ opacity: 0, y: -24 }}
                        transition={{ duration: 0.4 }}
                      >
                        <span className="text-amber-500 font-bold text-xs">+{item.coins}</span>
                        <span className="text-[10px]">&#129689;</span>
                      </motion.div>
                    )}
                  </AnimatePresence>
                  
                  {/* Today's reward glow ring */}
                  {item.isToday && (
                    <motion.div 
                      className="absolute -inset-1 rounded-full z-0"
                      style={{ background: "linear-gradient(135deg, rgba(251,191,36,0.4) 0%, rgba(245,158,11,0.3) 100%)" }}
                      animate={{ scale: [1, 1.2, 1], opacity: [0.6, 0.9, 0.6] }}
                      transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
                    />
                  )}
                  
                  <motion.div
                    whileHover={{ scale: 1.1, rotate: item.checked ? 0 : 5 }}
                    whileTap={{ scale: 0.95 }}
                    className={`relative w-10 h-10 rounded-full flex items-center justify-center mb-1 transition-all ${
                      item.isBig ? "w-11 h-11" : ""
                    }`}
                    style={{
                      background: item.checked 
                        ? "linear-gradient(135deg, #22c55e 0%, #16a34a 50%, #15803d 100%)"
                        : item.isToday
                        ? "linear-gradient(135deg, #fcd34d 0%, #fbbf24 50%, #f59e0b 100%)"
                        : "linear-gradient(135deg, #fef9c3 0%, #fef08a 50%, #fde047 100%)",
                      boxShadow: item.checked 
                        ? "0 4px 12px rgba(34,197,94,0.4), inset 0 1px 0 rgba(255,255,255,0.2)"
                        : item.isToday
                        ? "0 4px 16px rgba(251,191,36,0.5), inset 0 1px 0 rgba(255,255,255,0.3)"
                        : "0 2px 8px rgba(251,191,36,0.2), inset 0 1px 0 rgba(255,255,255,0.5)",
                      border: item.checked ? "2px solid rgba(255,255,255,0.3)" : item.isToday ? "2px solid rgba(255,255,255,0.4)" : "2px solid rgba(251,191,36,0.2)"
                    }}
                  >
                    {item.checked ? (
                      <Check className="w-5 h-5 text-white drop-shadow-sm" strokeWidth={2.5} />
                    ) : (
                      <div className="flex flex-col items-center">
                        <span className="text-[10px]">&#129689;</span>
                        <span className={`font-bold ${item.isToday ? "text-amber-800 text-[9px]" : "text-amber-700 text-[8px]"}`}>+{item.coins}</span>
                      </div>
                    )}
                  </motion.div>
                  <span className={`text-[10px] font-medium ${item.isToday ? "text-amber-600 font-semibold" : "text-gray-400"}`}>
                    {item.isToday ? "Today" : `Day ${item.day}`}
                  </span>
                </TapButton>
              ))}
            </div>
          </div>
        </motion.div>

        {/* Lobby Section */}
        <motion.div 
          className="px-4 mb-24"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6, duration: 0.4 }}
        >
          <div className="bg-white rounded-t-[22px] rounded-b-xl p-4 shadow-[0_2px_16px_rgba(0,0,0,0.04)] border border-gray-50">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <h3 className="font-semibold text-gray-800 text-[17px]">Lobby</h3>
                <div className="flex items-center gap-1.5 bg-emerald-50 px-2.5 py-1 rounded-full">
                  <motion.div 
                    className="w-[6px] h-[6px] bg-emerald-500 rounded-full"
                    animate={{ scale: [1, 1.3, 1], opacity: [1, 0.7, 1] }}
                    transition={{ duration: 1.5, repeat: Infinity }}
                  />
                  <span className="text-emerald-600 text-[10px] font-semibold tracking-wide">LIVE</span>
                </div>
              </div>
              <div className="flex items-center gap-1">
                <TapButton className="p-2.5 hover:bg-gray-50 rounded-xl transition-all duration-200">
                  <Search className="w-[18px] h-[18px] text-gray-400" strokeWidth={1.8} />
                </TapButton>
                <TapButton className="p-2.5 hover:bg-gray-50 rounded-xl transition-all duration-200">
                  <Calendar className="w-[18px] h-[18px] text-gray-400" strokeWidth={1.8} />
                </TapButton>
              </div>
            </div>
          </div>
        </motion.div>
      </div>

      {/* Floating Bottom Navigation Dock */}
      <div className="absolute bottom-0 left-0 right-0 px-4 pb-3 pointer-events-none">
        {/* Floating Dock */}
        <motion.div 
          className="relative rounded-[26px] px-2 py-2 pointer-events-auto"
          initial={{ y: 100, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.3, type: "spring", stiffness: 200, damping: 20 }}
          style={{
            background: "linear-gradient(180deg, rgba(255,253,250,0.97) 0%, rgba(255,250,245,0.95) 100%)",
            backdropFilter: "blur(20px)",
            WebkitBackdropFilter: "blur(20px)",
            boxShadow: "0 -2px 24px rgba(0,0,0,0.06), 0 4px 24px rgba(0,0,0,0.08), inset 0 1px 0 rgba(255,255,255,0.9)",
            border: "1px solid rgba(255,255,255,0.7)"
          }}
        >
          {/* Inner subtle gradient overlay */}
          <div className="absolute inset-0 rounded-[26px] bg-gradient-to-b from-white/30 to-transparent pointer-events-none" />
          
          <div className="relative flex items-center justify-around">
            {/* Home - Active */}
            <TapButton className="flex flex-col items-center gap-0.5 py-1.5 px-3">
              <div className="relative">
                <Home 
                  className="w-[22px] h-[22px]" 
                  strokeWidth={2} 
                  style={{ stroke: "url(#navGradient)" }}
                />
                <svg width="0" height="0" className="absolute">
                  <defs>
                    <linearGradient id="navGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                      <stop offset="0%" stopColor="#eb773c" />
                      <stop offset="100%" stopColor="#c73f41" />
                    </linearGradient>
                  </defs>
                </svg>
                {/* Active indicator dot */}
                <motion.div 
                  className="absolute -bottom-1 left-1/2 -translate-x-1/2 w-1 h-1 rounded-full bg-gradient-to-r from-[#eb773c] to-[#c73f41]"
                  layoutId="navIndicator"
                />
              </div>
              <span className="text-[10px] font-semibold bg-gradient-to-r from-[#eb773c] to-[#c73f41] bg-clip-text text-transparent">Home</span>
            </TapButton>
            
            {/* Ranking */}
            <TapButton className="flex flex-col items-center gap-0.5 py-1.5 px-3 hover:bg-black/[0.03] rounded-xl">
              <Trophy className="w-[22px] h-[22px] text-gray-400" strokeWidth={1.8} />
              <span className="text-[10px] text-gray-400 font-medium">Ranking</span>
            </TapButton>
            
            {/* Center Start Button with pulse glow and bounce */}
            <motion.button 
              className="relative -mt-6 mx-1 group"
              whileTap={{ scale: 0.9 }}
              whileHover={{ scale: 1.05 }}
              transition={{ type: "spring", stiffness: 400, damping: 17 }}
            >
              {/* Animated pulse glow */}
              <motion.div 
                className="absolute -inset-3 rounded-full"
                animate={{
                  scale: [1, 1.2, 1],
                  opacity: [0.3, 0.15, 0.3],
                }}
                transition={{
                  duration: 2,
                  repeat: Infinity,
                  ease: "easeInOut"
                }}
                style={{
                  background: "radial-gradient(circle, rgba(235,119,60,0.5) 0%, rgba(199,63,65,0.3) 50%, transparent 70%)",
                  filter: "blur(8px)"
                }}
              />
              {/* Button body */}
              <motion.div 
                className="relative w-14 h-14 rounded-full flex items-center justify-center border-[3px] border-white/95"
                animate={{ y: [0, -3, 0] }}
                transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
                style={{
                  background: "linear-gradient(180deg, #eb773c 0%, #e0613a 40%, #d65a3e 70%, #c73f41 100%)",
                  boxShadow: "0 4px 16px rgba(199,63,65,0.4), 0 2px 8px rgba(235,119,60,0.3), inset 0 1px 0 rgba(255,255,255,0.2)"
                }}
              >
                <div className="flex flex-col items-center">
                  <Plus className="w-5 h-5 text-white" strokeWidth={2.5} />
                  <span className="text-white text-[8px] font-bold tracking-wide -mt-0.5">Start</span>
                </div>
              </motion.div>
            </motion.button>
            
            {/* Redeem */}
            <TapButton className="flex flex-col items-center gap-0.5 py-1.5 px-3 hover:bg-black/[0.03] rounded-xl">
              <Gift className="w-[22px] h-[22px] text-gray-400" strokeWidth={1.8} />
              <span className="text-[10px] text-gray-400 font-medium">Redeem</span>
            </TapButton>
            
            {/* Profile */}
            <TapButton className="flex flex-col items-center gap-0.5 py-1.5 px-3 hover:bg-black/[0.03] rounded-xl">
              <User className="w-[22px] h-[22px] text-gray-400" strokeWidth={1.8} />
              <span className="text-[10px] text-gray-400 font-medium">Profile</span>
            </TapButton>
          </div>
        </motion.div>
      </div>

      {/* Sync Success Popup */}
      <AnimatePresence>
        {showSyncPopup && (
          <motion.div
            className="absolute inset-0 z-50 flex items-center justify-center pointer-events-none"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          >
            <motion.div
              className="bg-white rounded-2xl px-6 py-4 shadow-[0_8px_32px_rgba(0,0,0,0.12)] flex items-center gap-3"
              initial={{ scale: 0.8, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.8, y: 20, opacity: 0 }}
              transition={{ type: "spring", stiffness: 300, damping: 20 }}
            >
              <div className="w-10 h-10 bg-gradient-to-br from-emerald-400 to-green-500 rounded-full flex items-center justify-center">
                <Check className="w-5 h-5 text-white" strokeWidth={2.5} />
              </div>
              <div>
                <p className="font-semibold text-gray-800">Synced!</p>
                <p className="text-gray-500 text-sm">Data updated successfully</p>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Reward Claimed Modal */}
      <AnimatePresence>
        {showRewardPopup && (
          <>
            {/* Backdrop */}
            <motion.div
              className="absolute inset-0 z-40 bg-black/40 backdrop-blur-sm"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowRewardPopup(false)}
            />
            {/* Modal */}
            <motion.div
              className="absolute inset-x-4 bottom-24 z-50 bg-white rounded-3xl p-6 shadow-[0_16px_48px_rgba(0,0,0,0.15)]"
              initial={{ y: 300, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ y: 300, opacity: 0 }}
              transition={{ type: "spring", stiffness: 300, damping: 30 }}
            >
              <button 
                className="absolute top-4 right-4 p-2 hover:bg-gray-100 rounded-full transition-colors"
                onClick={() => setShowRewardPopup(false)}
              >
                <X className="w-5 h-5 text-gray-400" />
              </button>
              
              <div className="text-center">
                <motion.div 
                  className="w-20 h-20 bg-gradient-to-br from-amber-100 to-yellow-200 rounded-full flex items-center justify-center mx-auto mb-4 shadow-[0_4px_16px_rgba(251,191,36,0.3)]"
                  animate={{ rotate: [0, -5, 5, 0], scale: [1, 1.05, 1] }}
                  transition={{ duration: 0.5, delay: 0.2 }}
                >
                  <span className="text-4xl">&#127881;</span>
                </motion.div>
                <h3 className="text-xl font-bold text-gray-800 mb-2">Reward Claimed!</h3>
                <p className="text-gray-500 mb-4">{"You've earned your daily reward"}</p>
                <div className="flex items-center justify-center gap-2 bg-gradient-to-r from-amber-50 to-yellow-50 rounded-2xl py-3 px-6 border border-amber-200/50">
                  <div className="w-8 h-8 bg-gradient-to-br from-yellow-300 to-amber-400 rounded-full flex items-center justify-center shadow-md">
                    <span className="text-sm">&#129689;</span>
                  </div>
                  <span className="text-2xl font-bold text-amber-600">+10</span>
                  <span className="text-amber-500 font-medium">coins</span>
                </div>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </div>
  )
}
