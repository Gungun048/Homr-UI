import { FitnessApp } from "@/components/fitness-app"
import { PhonePreview } from "@/components/phone-preview"

export default function Home() {
  return (
    <main className="min-h-screen bg-gradient-to-br from-slate-100 via-slate-50 to-slate-100 flex items-center justify-center p-8">
      {/* Decorative background elements */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-20 left-20 w-72 h-72 bg-orange-200/30 rounded-full blur-3xl" />
        <div className="absolute bottom-20 right-20 w-96 h-96 bg-blue-200/20 rounded-full blur-3xl" />
        <div className="absolute top-1/2 left-1/3 w-64 h-64 bg-yellow-200/20 rounded-full blur-3xl" />
      </div>
      
      {/* Phone Preview Container */}
      <div className="relative z-10">
        <PhonePreview>
          <FitnessApp />
        </PhonePreview>
      </div>
    </main>
  )
}
